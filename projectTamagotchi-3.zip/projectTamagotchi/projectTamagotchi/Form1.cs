﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectTamagotchi
{
    public partial class Form1 : Form
    {
        bool klaar = false;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (progressBar2.Value < 80)
            {
                progressBar2.Value += 5;
            }
            else
            {
                progressBar2.Value = 100;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar2.Value >=1)
            {
                progressBar2.Value -= 5;
            }
            

            else
            {
                progressBar2.Value = 0;
                

                if (progressBar1.Value > 0)
                {
                    progressBar1.Value -= 1;
                }
               

                if (progressBar1.Value > 66)
                {
                    pictureBox1.Image = Properties.Resources._100_;
                    pictureBox1.Refresh();
                }
                if (progressBar1.Value > 33 && progressBar1.Value <= 66)
                {
                    pictureBox1.Image = Properties.Resources._70_30_;
                    pictureBox1.Refresh();
                }
                if (progressBar1.Value <=33)
                {
                    pictureBox1.Image = Properties.Resources._0_;
                    pictureBox1.Refresh();
                 
                }
                if (progressBar1.Value == 0 && klaar == false)
                {
                    klaar = true;
                    MessageBox.Show("Game Over");
                }
            }
             
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (progressBar3.Value < 80)
            {
                progressBar3.Value += 5;
            }
            else
            {
                progressBar3.Value = 100;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            hongerTimer.Start();
            dorstTimer.Start();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dorstTimer_Tick(object sender, EventArgs e)
        {
            if (progressBar3.Value >= 1)
            {
                progressBar3.Value -= 5;
            }


            else
            {
                progressBar3.Value = 0;


                if (progressBar1.Value > 0)
                {
                    progressBar1.Value -= 1;
                }


                if (progressBar1.Value > 66)
                {
                    pictureBox1.Image = Properties.Resources._100_;
                    pictureBox1.Refresh();
                }
                if (progressBar1.Value > 33 && progressBar1.Value <= 66)
                {
                    pictureBox1.Image = Properties.Resources._70_30_;
                    pictureBox1.Refresh();
                }
                if (progressBar1.Value <= 33)
                {
                    pictureBox1.Image = Properties.Resources._0_;
                    pictureBox1.Refresh();

                }
                if (progressBar1.Value == 0 && klaar == false)
                {
                    klaar = true;
                    MessageBox.Show("Game Over");
                }
            }

        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void progressBar3_Click(object sender, EventArgs e)
        {

        }

        private void progressBar2_Click(object sender, EventArgs e)
        {

        }
    }
}
